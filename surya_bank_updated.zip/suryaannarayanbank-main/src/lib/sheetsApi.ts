// src/lib/sheetsApi.ts
// Thin client for Google Apps Script backend that uses the Spreadsheet as a database.
// Configure VITE_GAS_URL in your .env (e.g., https://script.google.com/macros/s/AKfycb.../exec)
// Optionally set VITE_ADMIN_TOKEN to protect admin-only endpoints.

export type ApiResult<T> = { ok: true; data: T } | { ok: false; error: string };

const BASE_URL = import.meta.env.VITE_GAS_URL as string;
const ADMIN_TOKEN = import.meta.env.VITE_ADMIN_TOKEN as string | undefined;

async function request<T>(path: string, payload: any): Promise<ApiResult<T>> {
  if (!BASE_URL) {
    return { ok: false, error: "Missing VITE_GAS_URL. Set it in your .env file." };
  }
  try {
    const res = await fetch(BASE_URL + path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const json = await res.json();
    if (!res.ok || json.error) return { ok: false, error: json.error || res.statusText };
    return { ok: true, data: json.data as T };
  } catch (e: any) {
    return { ok: false, error: e?.message || "Network error" };
  }
}

export interface TransferInput {
  fromAccount: string;
  toAccount: string;
  amount: number;
  memo?: string;
}
export interface DepositInput {
  account: string;
  amount: number;
  memo?: string;
}
export interface WithdrawInput {
  account: string;
  amount: number;
  memo?: string;
}

export interface CardPayload {
  userId: string;
  nameOnCard: string;
  pinHash: string; // SHA-256 hex
  admin?: boolean;
}

export interface ChargePayload {
  cardNumber: string;
  cvv: string;
  pin: string;
  amount: number;
  description?: string;
}

export const api = {
  getUser: (emailOrUsername: string) =>
    request<any>("/getUser", { emailOrUsername }),

  getTransactions: (account: string) =>
    request<any[]>("/getTransactions", { account }),

  transfer: (input: TransferInput) =>
    request<{ txId: string }>("/transfer", input),

  deposit: (input: DepositInput) =>
    request<{ txId: string }>("/deposit", { ...input, adminToken: ADMIN_TOKEN }),

  withdraw: (input: WithdrawInput) =>
    request<{ txId: string }>("/withdraw", { ...input, adminToken: ADMIN_TOKEN }),

  // Credit cards
  createCard: (payload: CardPayload) =>
    request<{ cardNumber: string }>(
      "/createCard",
      { ...payload, adminToken: ADMIN_TOKEN }
    ),

  chargeCard: (payload: ChargePayload) =>
    request<{ authCode: string; txId: string }>("/chargeCard", payload),

  adminListCards: (userId?: string) =>
    request<any[]>("/admin/listCards", { userId, adminToken: ADMIN_TOKEN }),

  adminUpdateCard: (cardNumber: string, patch: any) =>
    request<void>("/admin/updateCard", { cardNumber, patch, adminToken: ADMIN_TOKEN }),

  adminUnlockCard: (cardNumber: string, permanent?: boolean) =>
    request<void>("/admin/unlockCard", { cardNumber, permanent, adminToken: ADMIN_TOKEN }),
};