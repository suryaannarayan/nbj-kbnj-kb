import React, { useMemo, useState } from "react";
import MainLayout from "@/components/layout/MainLayout";
import { useAuth } from "@/context/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { api } from "@/lib/sheetsApi";

function sha256(str: string): Promise<string> {
  const enc = new TextEncoder();
  return crypto.subtle.digest("SHA-256", enc.encode(str)).then(buf =>
    Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("")
  );
}

const CreditCardPage: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [nameOnCard, setNameOnCard] = useState<string>("");
  const [pin, setPin] = useState<string>("");
  const [creating, setCreating] = useState<boolean>(false);
  const isAdmin = !!user?.isAdmin;

  const bankEmail = import.meta.env.VITE_BANK_ADMIN_EMAIL || "contact@yourbank.example";

  const canCreate = !!user && nameOnCard.trim().length >= 3 && /^\d{6}$/.test(pin);

  const onCreate = async () => {
    if (!user) return;
    setCreating(true);
    try {
      const pinHash = await sha256(pin);
      const res = await api.createCard({
        userId: user.id,
        nameOnCard: nameOnCard.trim(),
        pinHash,
      });
      if (res.ok) {
        toast({ title: "Card created", description: "Your card is ready to use for purchases." });
      } else {
        toast({ title: "Error", description: res.error, variant: "destructive" });
      }
    } finally {
      setCreating(false);
    }
  };

  return (
    <MainLayout>
      <div className="max-w-3xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Create Credit Card</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm mb-1">Name on Card</label>
                <Input value={nameOnCard} onChange={e=>setNameOnCard(e.target.value)} placeholder="Full name as per profile" />
              </div>
              <div>
                <label className="block text-sm mb-1">Set 6-digit PIN</label>
                <Input value={pin} onChange={e=>setPin(e.target.value.replace(/\D/g,''))} placeholder="******" maxLength={6} />
              </div>
            </div>
            <Button onClick={onCreate} disabled={!canCreate || creating}>{creating ? "Creating..." : "Create card"}</Button>
            <p className="text-sm text-gray-600">If you get locked out, contact admin: <a className="underline" href={`mailto:${bankEmail}`}>{bankEmail}</a></p>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
};

export default CreditCardPage;